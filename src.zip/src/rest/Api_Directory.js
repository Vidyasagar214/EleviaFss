import axios from 'axios';

export const baseUrl = 'https://demo3.eleviasoftware.com/FieldServices.75.BL/DirectRouter/Index';

// export const axiosRequest = axios.create({
//     baseUrl,
//     headers: { 'Content-Type': 'application/json' }
// });
